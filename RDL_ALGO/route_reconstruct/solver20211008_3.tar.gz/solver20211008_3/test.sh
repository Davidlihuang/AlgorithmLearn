Input_JSON=../input/design_data_cLoc.json
Input_SDC_0=../input/u_core_context.sdc 
Input_SDC_1=../input/u_mem_context1.sdc 
Input_SDC_2=../input/u_mem_context2.sdc
echo $Input_JSON
echo $Input_SDC_0 $Input_SDC_1 $Input_SDC_2
echo $Input_SDC_1
echo $Input_SDC_2